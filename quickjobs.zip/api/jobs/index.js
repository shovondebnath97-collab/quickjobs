const { app, db } = require('../../server');

// FETCH COMPREHENSIVE PUBLIC VACANCIES LIST WITH DYNAMIC MULTI-FILTER CRITERIA
app.get('/api/jobs', async (req, res) => {
    try {
        let sql = `SELECT jobs.*, employer_profiles.company_name, employer_profiles.company_logo 
                   FROM jobs 
                   JOIN employer_profiles ON jobs.employer_id = employer_profiles.user_id 
                   WHERE jobs.status = 'active'`;
        const params = [];

        if (req.query.keyword) {
            sql += ` AND (jobs.job_title LIKE ? OR jobs.description LIKE ?)`;
            params.push(`%${req.query.keyword}%`, `%${req.query.keyword}%`);
        }
        if (req.query.location) {
            sql += ` AND jobs.job_location LIKE ?`;
            params.push(`%${req.query.location}%`);
        }
        if (req.query.job_type) {
            sql += ` AND jobs.job_type = ?`;
            params.push(req.query.job_type);
        }

        sql += ` ORDER BY jobs.created_at DESC`;
        const [results] = await db.query(sql, params);
        res.status(200).json(results);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// PUBLISH A NEW RECRUITMENT NOTICE
app.post('/api/jobs/create', async (req, res) => {
    try {
        const { employer_id, category_id, job_title, job_type, experience_level, salary_range, job_location, description, requirements, deadline } = req.body;
        
        await db.query(
            `INSERT INTO jobs (employer_id, category_id, job_title, job_type, experience_level, salary_range, job_location, description, requirements, deadline, status) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')`,
            [employer_id, category_id, job_title, job_type, experience_level, salary_range, job_location, description, requirements, deadline]
        );
        res.status(201).json({ message: 'Recruitment post published across active directories.' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
