const { app, db } = require('../../server');
const multer = require('multer');
const path = require('path');

// Configure Disk Storage Parameters targeting unique file destination tracks
const uploadConfiguration = multer.diskStorage({
    destination: (req, file, cb) => {
        if (file.fieldname === "resume") cb(null, './uploads/resumes/');
        else if (file.fieldname === "avatar") cb(null, './uploads/profile-photo/');
        else cb(null, './uploads/documents/');
    },
    filename: (req, file, cb) => {
        cb(null, `FILE-${Date.now()}${path.extname(file.originalname)}`);
    }
});

const uploadEngine = multer({ storage: uploadConfiguration });

// MANAGE CV UPLOADS & DEMOGRAPHIC PROFILING ENDPOINT
app.post('/api/resumes/update', uploadEngine.fields([{ name: 'resume', maxCount: 1 }, { name: 'avatar', maxCount: 1 }]), async (req, res) => {
    try {
        const { user_id, title, phone, skills, bio } = req.body;
        
        let resumeUrl = req.files['resume'] ? `/uploads/resumes/${req.files['resume'][0].filename}` : null;
        let avatarUrl = req.files['avatar'] ? `/uploads/profile-photo/${req.files['avatar'][0].filename}` : null;

        // Dynamic parameter injection assembly
        let updateSql = `UPDATE jobseeker_profiles SET title = ?, phone = ?, skills = ?, bio = ?`;
        let params = [title, phone, skills, bio];

        if (resumeUrl) { updateSql += `, resume_file = ?`; params.push(resumeUrl); }
        if (avatarUrl) { updateSql += `, profile_photo = ?`; params.push(avatarUrl); }

        updateSql += ` WHERE user_id = ?`;
        params.push(user_id);

        await db.query(updateSql, params);
        res.status(200).json({ message: 'Profile portfolio updates finalized across system registers.' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
