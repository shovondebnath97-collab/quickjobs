const { app, db, bcrypt, jwt, JWT_SECRET } = require('../../server');

// USER REGISTRATION ENDPOINT
app.post('/api/auth/register', async (req, res) => {
    try {
        const { name, email, password, role, company_name } = req.body;
        
        // Check if account already exists
        const [existing] = await db.query('SELECT id FROM users WHERE email = ?', [email]);
        if (existing.length > 0) return res.status(400).json({ error: 'Email already registered.' });

        // Securely hash authentication parameters
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Transaction safety wrapper
        const [userResult] = await db.query(
            'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
            [name, email, hashedPassword, role]
        );
        const userId = userResult.insertId;

        // If employer type account, map auxiliary business card matrix profile automatically
        if (role === 'employer') {
            await db.query(
                'INSERT INTO employer_profiles (user_id, company_name) VALUES (?, ?)',
                [userId, company_name || 'New Organization Ledger']
            );
        } else if (role === 'jobseeker') {
            await db.query('INSERT INTO jobseeker_profiles (user_id) VALUES (?)', [userId]);
        }

        res.status(201).json({ message: 'Account creation processed successfully.' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// SYSTEM LOGIN ENDPOINT
app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const [users] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
        if (users.length === 0) return res.status(401).json({ error: 'Invalid security credentials.' });

        const user = users[0];
        const match = await bcrypt.compare(password, user.password);
        if (!match) return res.status(401).json({ error: 'Authentication match failed.' });

        // Generate JSON Web Token authorization cookies payload
        const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '24h' });
        res.status(200).json({ token, role: user.role, name: user.name });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
