USE quickjobs_db;

-- Populate Core Categories
INSERT INTO categories (id, name, icon) VALUES
(1, 'Garments & Textile', 'fa-shirt'),
(2, 'Sales & Marketing', 'fa-chart-line'),
(3, 'IT & Software Engineering', 'fa-laptop-code'),
(4, 'Bank & Finance', 'fa-building-columns');

-- Populate Production Industries
INSERT INTO industries (id, name) VALUES
(1, 'Ready-Made Garments (RMG)'),
(2, 'E-Commerce & Retail'),
(3, 'Information Technology'),
(4, 'Food & Agro Processing');

-- Seed Standard Master System Admin Account (Password hash for 'admin123')
INSERT INTO users (id, name, email, password, role, status) VALUES
(1, 'System Administrator', 'admin@quickjobs.com.bd', '$2b$10$E7v6Xb1V7x1v1x1v1x1v1e1x1v1x1v1x1v1x1v1x1v1x1v1x1v1x1', 'admin', 'active');
