document.addEventListener("DOMContentLoaded", () => {
    // 1. Inject Global Navbar
    const navbarContainer = document.getElementById("main-navbar");
    if (navbarContainer) {
        fetch("/components/navbar.html")
            .then(response => {
                if (!response.ok) throw new Error("Navbar file missing");
                return response.text();
            })
            .then(data => {
                navbarContainer.innerHTML = data;
                highlightActiveLink();
            })
            .catch(error => console.error("Error loading navbar:", error));
    }
});

/**
 * Automatically applies an 'active' style class 
 * to the navbar link matching the current URL path.
 */
function highlightActiveLink() {
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll(".nav-links a");
    
    navLinks.forEach(link => {
        if (link.getAttribute("href") === currentPath) {
            link.classList.add("active");
            link.style.color = "var(--primary-color)";
        }
    });
}
document.addEventListener("DOMContentLoaded", () => {
    // 1. Dynamic Header Injection Block
    const navbarContainer = document.getElementById("main-navbar");
    if (navbarContainer) {
        fetch("/components/navbar.html")
            .then(res => res.text())
            .then(data => { navbarContainer.innerHTML = data; });
    }

    // 2. Dynamic Footer Injection Block
    const footerContainer = document.getElementById("main-footer");
    if (footerContainer) {
        fetch("/components/footer.html")
            .then(res => res.text())
            .then(data => { footerContainer.innerHTML = data; });
    }
});/**
 * Global API Service Transporter Layer for QuickJobs
 */
const QuickJobsAPI = {
    serverUrl: 'http://localhost:3000',

    async postData(endpoint, dataPayload) {
        const response = await fetch(`${this.serverUrl}${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dataPayload)
        });
        return response.json();
    },

    async uploadMultipart(endpoint, formDataPayload) {
        const response = await fetch(`${this.serverUrl}${endpoint}`, {
            method: 'POST',
            body: formDataPayload // Bound content headers are applied automatically by modern browser engines
        });
        return response.json();
    }
};

