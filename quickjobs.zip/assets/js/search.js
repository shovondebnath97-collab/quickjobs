// Mock Database Array representing backend data records
const mockJobsData = [
    {
        id: 101,
        title: "Quality Controller / Inspector",
        company: "Shepherd Jeans Limited",
        type: "full-time",
        experience: "mid",
        location: "Mymensingh",
        salaryType: "negotiable",
        salaryVal: 0,
        salaryText: "Negotiable",
        iconClass: "fa-shirt"
    },
    {
        id: 102,
        title: "Junior Frontend Developer",
        company: "TechMinds Solutions",
        type: "remote",
        experience: "entry",
        location: "Dhaka",
        salaryType: "range",
        salaryVal: 40000,
        salaryText: "35,000 - 45,000 BDT",
        iconClass: "fa-laptop-code"
    },
    {
        id: 103,
        title: "Production Supervisor",
        company: "Apex Textiles",
        type: "full-time",
        experience: "senior",
        location: "Gazipur",
        salaryType: "range",
        salaryVal: 55000,
        salaryText: "50,000 - 60,000 BDT",
        iconClass: "fa-industry"
    }
];

document.addEventListener("DOMContentLoaded", () => {
    initSearchFilters();
});

function initSearchFilters() {
    const formInputs = document.querySelectorAll('.filter-sidebar input');
    const clearBtn = document.querySelector('.clear-filters-btn');

    // Load initial parameters out of the URL (from homepage search box)
    const urlParams = new URLSearchParams(window.location.search);
    const keywordParam = urlParams.get('keyword') || '';
    const locationParam = urlParams.get('location') || '';

    // Run primary evaluation
    filterAndRenderJobs(keywordParam, locationParam);

    // Add continuous input change listeners to update results instantly
    formInputs.forEach(input => {
        input.addEventListener('change', () => {
            filterAndRenderJobs();
        });
    });

    // Reset button action functionality
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            document.querySelectorAll('.filter-group input[type="checkbox"]').forEach(el => el.checked = false);
            document.querySelector('input[name="salary"][value="any"]').checked = true;
            filterAndRenderJobs();
        });
    }
}

function filterAndRenderJobs(urlKeyword = '', urlLocation = '') {
    const container = document.getElementById('jobs-list-container');
    const countDisplay = document.querySelector('.results-count');
    if (!container) return;

    // 1. Gather current dynamic values from UI
    const selectedTypes = Array.from(document.querySelectorAll('input[name="job_type"]:checked')).map(el => el.value);
    const selectedExp = Array.from(document.querySelectorAll('input[name="experience"]:checked')).map(el => el.value);
    const selectedSalaryRange = document.querySelector('input[name="salary"]:checked').value;

    // 2. Perform conditional filtering match pass
    const filtered = mockJobsData.filter(job => {
        // Evaluate homepage URL inputs if present
        if (urlKeyword && !job.title.toLowerCase().includes(urlKeyword.toLowerCase()) && !job.company.toLowerCase().includes(urlKeyword.toLowerCase())) return false;
        if (urlLocation && !job.location.toLowerCase().includes(urlLocation.toLowerCase())) return false;

        // Evaluate Checkbox filters
        if (selectedTypes.length > 0 && !selectedTypes.includes(job.type)) return false;
        if (selectedExp.length > 0 && !selectedExp.includes(job.experience)) return false;

        // Evaluate Radio Salary filters
        if (selectedSalaryRange === 'under-20' && (job.salaryVal === 0 || job.salaryVal >= 20000)) return false;
        if (selectedSalaryRange === '20-50' && (job.salaryVal < 20000 || job.salaryVal > 50000)) return false;
        if (selectedSalaryRange === 'above-50' && job.salaryVal <= 50000) return false;

        return true;
    });

    // 3. Clear container structure and rebuild interface
    container.innerHTML = '';
    countDisplay.innerHTML = `Showing <strong>${filtered.length}</strong> matching job positions`;

    if (filtered.length === 0) {
        container.innerHTML = `<div class="no-results">No active job vacancies match your specific search criteria. Try removing standard filters.</div>`;
        return;
    }

    filtered.forEach(job => {
        const cardHtml = `
            <div class="job-card">
                <div class="job-card-logo ${job.type === 'remote' ? 'IT' : ''}">
                    <i class="fa-solid ${job.iconClass}"></i>
                </div>
                <div class="job-card-body">
                    <span class="job-badge ${job.type}">${job.type.replace('-', ' ')}</span>
                    <h3 class="job-title"><a href="job-details.html?id=${job.id}">${job.title}</a></h3>
                    <p class="company-name">${job.company}</p>
                    <div class="job-meta">
                        <span><i class="fa-solid fa-location-dot"></i> ${job.location}, Bangladesh</span>
                        <span><i class="fa-solid fa-wallet"></i> ${job.salaryText}</span>
                    </div>
                </div>
                <div class="job-card-action">
                    <a href="job-details.html?id=${job.id}" class="btn btn-outline">View Details</a>
                </div>
            </div>
        `;
        container.innerHTML += cardHtml;
    });
}
