/**
 * Toggles form fields depending on whether a Job Seeker or Employer is registering.
 */
function switchRole(selectedRole) {
    const roleInput = document.getElementById('user-role');
    const seekerBtn = document.getElementById('role-seeker-btn');
    const employerBtn = document.getElementById('role-employer-btn');
    const companyGroup = document.getElementById('company-name-group');
    const nameLabel = document.getElementById('name-label');
    const companyInput = document.getElementById('reg-company');

    roleInput.value = selectedRole;

    if (selectedRole === 'employer') {
        seekerBtn.classList.remove('active');
        employerBtn.classList.add('active');
        companyGroup.classList.remove('hidden');
        companyInput.setAttribute('required', 'required');
        nameLabel.textContent = "Contact Person Name";
    } else {
        employerBtn.classList.remove('active');
        seekerBtn.classList.add('active');
        companyGroup.classList.add('hidden');
        companyInput.removeAttribute('required');
        nameLabel.textContent = "Full Name";
    }
}

/**
 * Validates registration parameters before forwarding.
 */
function handleRegistration(event) {
    event.preventDefault();

    const password = document.getElementById('reg-password').value;
    const confirmPassword = document.getElementById('reg-confirm-password').value;

    if (password.length < 6) {
        alert("Security requirement: Password must consist of 6 or more characters.");
        return;
    }

    if (password !== confirmPassword) {
        alert("Input mismatch: The password fields do not match.");
        return;
    }

    // Capture form values to prepare for backend transmission
    const formData = new FormData(document.getElementById('register-form'));
    console.log("Submitting account setup configurations: ", Object.fromEntries(formData));
    
    alert("Success! Your registration data has been captured. Moving towards next implementation phase.");
}/**
 * Intercepts login submission, checks credentials, 
 * and routes users based on their target profile role type.
 */
function handleLogin(event) {
    event.preventDefault();

    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;

    console.log(`Processing login request for credentials target: ${email}`);

    // Mock Login Routing Simulation Layer
    // In a live environment, this role profile would come from your secure database response tokens.
    if (email.toLowerCase().includes('employer') || email.toLowerCase().includes('hr')) {
        alert("Verification Approved! Directing you to Employer Workspace.");
        window.location.href = "/employer/dashboard.html";
    } else if (email.toLowerCase().includes('admin')) {
        alert("Master System Admin Authorized.");
        window.location.href = "/admin/dashboard.html";
    } else {
        // Fallback default routing sets to job seekers profile
        alert("Verification Approved! Directing you to Jobseeker Dashboard.");
        window.location.href = "/jobseeker/dashboard.html";
    }
}

