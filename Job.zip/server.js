const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve Global Frontend Layout Assets and Public Pages
app.use(express.static(path.join(__dirname, '/')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Secure Relational Database Connection Pooling Configuration
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'your_mysql_password',
    database: 'quickjobs_db',
    waitForConnections: true,
    connectionLimit: 10
}).promise();

const JWT_SECRET = 'quickjobs_master_security_token_hash_2026';

module.exports = { app, db, bcrypt, jwt, JWT_SECRET };

// Import and mount operational routing sub-modules
require('./api/auth/index');
require('./api/jobs/index');
require('./api/resumes/index');

app.listen(3000, () => console.log('QuickJobs System Core Engine running online on port 3000.'));
